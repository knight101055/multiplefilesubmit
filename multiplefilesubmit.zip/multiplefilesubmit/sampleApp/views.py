from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from .models import FileList
from .forms import UploadFiles

# Create your views here.

def test(request):
    return HttpResponse('<h1>Hello World!</h1>')

def formpage(request):
    form = UploadFiles()
    print(form.fields)
    return render(request, "sampleform.html", {"form": form})

def upload(request):
    if request.method == 'POST':
        form = UploadFiles(request.POST, request.FILES)
        if form.is_valid():
            files = []
            if 'file_path' in request.FILES:
                for file in request.FILES.getlist('file_path'):
                    files.append(FileList(file_path=file))
            # print(len(files))
            if len(files) > 0:
                try:
                    FileList.objects.bulk_create(files)
                    messages.success(request, "File(s) has been uploaded successfully.")
                except Exception as ex:
                    messages.error(request, ex)
        else:
            messages.error(request, 'Form data is invalid')

    return redirect('home')