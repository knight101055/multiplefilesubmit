# Import forms of Django
from django import forms
# Import FileList Model
from sampleApp.models import FileList

# Upload File Form
class UploadFiles(forms.ModelForm):
    file_path = forms.FileField(label="Select Multiple File", help_text="The Avatar field is required.", widget = forms.FileInput(attrs={'multiple':'multiple', 'class':'file-input'}))
    class Meta:
        model = FileList
        fields = ('file_path',)