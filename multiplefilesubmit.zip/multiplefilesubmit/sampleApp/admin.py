from django.contrib import admin
from sampleApp.models import FileList


# Register your models here.
admin.site.register(FileList)
