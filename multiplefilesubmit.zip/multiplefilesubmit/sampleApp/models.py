from django.db import models

# Create your models here.

class FileList(models.Model):
    file_path = models.FileField(blank=True,null = True, upload_to='fileuploads/')
